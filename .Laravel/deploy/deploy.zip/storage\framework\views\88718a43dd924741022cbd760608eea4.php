<?php $__env->startSection('title', 'Edit Kendaraan'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl">
    <div class="flex items-center gap-4 mb-6">
        <a href="<?php echo e(route('admin.vehicles')); ?>" class="material-symbols-outlined text-primary p-2 hover:bg-gray-100 rounded-full">arrow_back</a>
        <h2 class="text-2xl font-bold text-primary">Edit Kendaraan</h2>
    </div>

    <div class="glass-card rounded-xl p-8 shadow-lg">
        <form action="<?php echo e(route('admin.vehicles.update', $vehicle->id)); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div>
                <label class="block text-sm font-bold text-primary mb-2">Nama Kendaraan</label>
                <input type="text" name="name" value="<?php echo e($vehicle->name); ?>" class="w-full border-outline-variant rounded-lg p-3 focus:ring-primary focus:border-primary" required>
            </div>

            <div>
                <label class="block text-sm font-bold text-primary mb-2">No. Plat</label>
                <input type="text" name="license_plate" value="<?php echo e($vehicle->license_plate); ?>" class="w-full border-outline-variant rounded-lg p-3 focus:ring-primary focus:border-primary" required>
            </div>

            <div>
                <label class="block text-sm font-bold text-primary mb-2">Kapasitas Kursi</label>
                <input type="number" name="capacity" value="<?php echo e($vehicle->capacity); ?>" class="w-full border-outline-variant rounded-lg p-3 focus:ring-primary focus:border-primary" required>
            </div>

            <div class="pt-4">
                <button type="submit" class="w-full bg-primary text-white py-4 rounded-lg font-bold text-lg shadow-md hover:opacity-90 transition-all">Update Kendaraan</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Program1\Projects\Shuttle\.Laravel\deploy\resources\views\admin\vehicles\edit.blade.php ENDPATH**/ ?>