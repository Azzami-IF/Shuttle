<?php $__env->startSection('title','Reset Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto mt-12">
    <div class="glass-card p-6">
        <h2 class="text-2xl font-bold mb-4">Reset Password</h2>
        <form method="POST" action="<?php echo e(route('admin.password.update')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">
            <div class="mb-3">
                <label class="block text-sm text-gray-700">Email</label>
                <input name="email" type="email" required class="w-full border px-3 py-2 rounded" />
            </div>
            <div class="mb-3">
                <label class="block text-sm text-gray-700">Password</label>
                <input name="password" type="password" required class="w-full border px-3 py-2 rounded" />
            </div>
            <div class="mb-3">
                <label class="block text-sm text-gray-700">Confirm Password</label>
                <input name="password_confirmation" type="password" required class="w-full border px-3 py-2 rounded" />
            </div>
            <div class="flex justify-end">
                <button class="bg-primary text-white px-4 py-2 rounded">Reset</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Program1\Projects\Shuttle\.Laravel\deploy\resources\views\admin\reset.blade.php ENDPATH**/ ?>