<?php $__env->startComponent('mail::message'); ?>
# Trip Completed - Safe Arrival! ✅

Hi <?php echo e($booking->user->name); ?>,

Your trip has been completed successfully. Thank you for traveling with us!

<?php $__env->startComponent('mail::panel'); ?>
**Trip Summary:**
- From: <?php echo e($schedule->origin); ?> → <?php echo e($schedule->destination); ?>

- Date: <?php echo e($schedule->departure_time->format('d F Y')); ?>

- Driver: <?php echo e($schedule->driver->name); ?>

- Vehicle: <?php echo e($schedule->vehicle->name); ?>

- Amount Paid: Rp <?php echo e(number_format($schedule->price, 0, ',', '.')); ?>

<?php echo $__env->renderComponent(); ?>

**What's next?**
1. Rate your driver to help us improve our service
2. You can book again anytime for future trips
3. Check your email for your trip receipt and invoice

<?php $__env->startComponent('mail::button', ['url' => config('app.url') . '/bookings']); ?>
View My Bookings
<?php echo $__env->renderComponent(); ?>

If you have any feedback or issues with your trip, please let us know. We'd love to hear from you!

**Have a great day!**

Best regards,  
<?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Program1\Projects\Shuttle\.Laravel\deploy\resources\views\emails\trip-completed.blade.php ENDPATH**/ ?>