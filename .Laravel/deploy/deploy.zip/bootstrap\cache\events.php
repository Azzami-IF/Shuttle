<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\TripCompleted' => 
    array (
      0 => 'App\\Listeners\\NotifyPassengersOfTripCompletion@handle',
    ),
    'App\\Events\\TripStarted' => 
    array (
      0 => 'App\\Listeners\\NotifyPassengersOfTripStart@handle',
    ),
    'App\\Events\\PaymentConfirmed' => 
    array (
      0 => 'App\\Listeners\\SendPaymentConfirmationEmail@handle',
    ),
  ),
);