<?php $__env->startComponent('mail::message'); ?>
# Trip Started - Driver on the Way! 🚌

Hi <?php echo e($booking->user->name); ?>,

Great news! Your trip is now starting. Your driver is on the way to pick you up.

<?php $__env->startComponent('mail::panel'); ?>
**Trip Details:**
- From: <?php echo e($schedule->origin); ?> → <?php echo e($schedule->destination); ?>

- Date: <?php echo e($schedule->departure_time->format('d F Y')); ?>

- Time: <?php echo e($schedule->departure_time->format('H:i')); ?>

- Driver: <?php echo e($schedule->driver->name); ?>

- Rating: <?php echo e($schedule->driver->rating); ?>

- Your Seat: Seat <?php echo e($booking->seat->seat_number); ?>

<?php echo $__env->renderComponent(); ?>

**What to do now:**
1. Be ready 5 minutes before the departure time
2. Keep your phone charged for real-time tracking
3. Have your booking reference ready when the driver arrives

**Booking Reference:** <?php echo e($booking->id); ?>


You can track your driver's real-time location in the app.

<?php $__env->startComponent('mail::button', ['url' => config('app.url') . '/booking/' . $booking->id]); ?>
Track Your Trip
<?php echo $__env->renderComponent(); ?>

Thank you for choosing Ambatu Bus!

Best regards,  
<?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Program1\Projects\Shuttle\.Laravel\deploy\resources\views\emails\trip-started.blade.php ENDPATH**/ ?>