<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px;">
        <h2 style="color: #333;">Trip Update</h2>
        <p style="color: #666;">Dear <?php echo e($booking->user->name); ?>,</p>
        <p style="color: #666;">We have an update regarding your upcoming trip.</p>
        
        <h3 style="color: #333; margin-top: 20px;">Trip Details</h3>
        <ul style="color: #666;">
            <li><strong>Booking ID:</strong> <?php echo e($booking->id); ?></li>
            <li><strong>From:</strong> <?php echo e($schedule->origin); ?></li>
            <li><strong>To:</strong> <?php echo e($schedule->destination); ?></li>
            <li><strong>Departure:</strong> <?php echo e($schedule->departure_time); ?></li>
            <li><strong>Seat:</strong> <?php echo e($booking->seat->seat_number ?? 'N/A'); ?></li>
        </ul>
        
        <h3 style="color: #333; margin-top: 20px;">Update Message</h3>
        <p style="color: #666;"><?php echo e($message); ?></p>
        
        <p style="color: #666; margin-top: 20px;">Please contact us if you need further assistance.</p>
    </div>
</div><?php /**PATH C:\Program1\Projects\Shuttle\.Laravel\deploy\resources\views\emails\trip-update.blade.php ENDPATH**/ ?>