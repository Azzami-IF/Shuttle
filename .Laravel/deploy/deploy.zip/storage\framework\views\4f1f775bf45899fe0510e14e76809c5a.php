<?php $__env->startSection('title','Edit Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto">
    <div class="glass-card p-6">
        <h2 class="text-2xl font-bold mb-4">Edit Pengguna</h2>
        <form method="POST" action="<?php echo e(route('admin.users.update', $user)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label class="block text-sm text-gray-700">Nama</label>
                <input name="name" type="text" value="<?php echo e($user->name); ?>" required class="w-full border px-3 py-2 rounded" />
            </div>
            <div class="mb-3">
                <label class="block text-sm text-gray-700">Email</label>
                <input name="email" type="email" value="<?php echo e($user->email); ?>" required class="w-full border px-3 py-2 rounded" />
            </div>
            <div class="mb-3">
                <label class="block text-sm text-gray-700">Role</label>
                <select name="role" class="w-full border px-3 py-2 rounded">
                    <option value="customer" <?php echo e($user->role === 'customer' ? 'selected' : ''); ?>>Customer</option>
                    <option value="driver" <?php echo e($user->role === 'driver' ? 'selected' : ''); ?>>Driver</option>
                    <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Admin</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="block text-sm text-gray-700">Phone</label>
                <input name="phone" type="text" value="<?php echo e($user->phone); ?>" class="w-full border px-3 py-2 rounded" />
            </div>
            <div class="mb-3">
                <label class="block text-sm text-gray-700">Driver Code (optional)</label>
                <input name="driver_code" type="text" value="<?php echo e($user->driver_code); ?>" class="w-full border px-3 py-2 rounded" />
            </div>
            <div class="mb-3">
                <label class="block text-sm text-gray-700">Password (kosongkan untuk tetap)</label>
                <input name="password" type="password" class="w-full border px-3 py-2 rounded" />
            </div>
            <div class="flex justify-end">
                <button class="bg-primary text-white px-4 py-2 rounded">Simpan</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Program1\Projects\Shuttle\.Laravel\deploy\resources\views\admin\users\edit.blade.php ENDPATH**/ ?>