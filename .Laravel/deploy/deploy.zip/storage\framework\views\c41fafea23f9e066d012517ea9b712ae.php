<?php $__env->startSection('title', 'Manajemen Jadwal'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-col md:flex-row items-center justify-between mb-6 gap-4">
    <h2 class="text-2xl font-bold text-primary">Daftar Jadwal Shuttle</h2>

    <div class="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
        <form action="<?php echo e(route('admin.schedules')); ?>" method="GET" class="flex gap-2 w-full sm:w-auto">
            <input type="text" name="origin" value="<?php echo e(request('origin')); ?>"
                class="border-outline-variant rounded-lg px-3 py-2 text-sm focus:ring-primary focus:border-primary"
                placeholder="Asal">
            <input type="text" name="destination" value="<?php echo e(request('destination')); ?>"
                class="border-outline-variant rounded-lg px-3 py-2 text-sm focus:ring-primary focus:border-primary"
                placeholder="Tujuan">
            <button type="submit" class="bg-secondary-container text-secondary p-2 rounded-lg">
                <span class="material-symbols-outlined">search</span>
            </button>
        </form>

        <a href="<?php echo e(route('admin.schedules.create')); ?>" class="bg-primary text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 whitespace-nowrap w-full sm:w-auto justify-center">
            <span class="material-symbols-outlined">add</span>
            Tambah Jadwal
        </a>
    </div>
</div>

<div class="bg-white border border-outline-variant rounded-xl overflow-hidden shadow-sm">
    <table class="w-full text-left">
        <thead class="bg-gray-50 border-b border-outline-variant">
            <tr>
                <th class="px-6 py-3 text-sm font-bold text-primary uppercase">Rute</th>
                <th class="px-6 py-3 text-sm font-bold text-primary uppercase">Waktu</th>
                <th class="px-6 py-3 text-sm font-bold text-primary uppercase">Kendaraan / Supir</th>
                <th class="px-6 py-3 text-sm font-bold text-primary uppercase text-right">Aksi</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-outline-variant">
            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4">
                    <p class="font-bold text-primary"><?php echo e($schedule->origin); ?> → <?php echo e($schedule->destination); ?></p>
                </td>
                <td class="px-6 py-4 text-on-surface-variant">
                    <?php echo e(\Carbon\Carbon::parse($schedule->departure_time)->format('d M Y, H:i')); ?>

                </td>
                <td class="px-6 py-4">
                    <p class="text-sm font-medium text-primary"><?php echo e($schedule->vehicle->name); ?></p>
                    <p class="text-xs text-on-surface-variant">Supir: <?php echo e($schedule->driver->name); ?></p>
                </td>
                <td class="px-6 py-4 text-right">
                    <form action="<?php echo e(route('admin.schedules.delete', $schedule->id)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-500 hover:text-red-700" onclick="return confirm('Hapus jadwal ini?')">
                            <span class="material-symbols-outlined">delete</span>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Program1\Projects\Shuttle\.Laravel\deploy\resources\views\admin\schedules\index.blade.php ENDPATH**/ ?>